import React from 'react';
import { FEATURE_META, CLASS_NAMES, CLASS_COLORS } from '../ml/models';

/**
 * Right-hand panel: controls for a market analyst to tweak the Decision Tree.
 * All labels are in plain business language, not ML jargon.
 */
export default function TweakPanel({ params, setParams, result }) {
  const upd = (key, val) => setParams((p) => ({ ...p, [key]: val }));

  const updWeight = (idx, val) =>
    setParams((p) => {
      const w = [...p.classWeights];
      w[idx] = +val;
      return { ...p, classWeights: w };
    });

  const togFeat = (idx) =>
    setParams((p) => {
      const cur  = p.activeFeatures;
      const next = cur.includes(idx)
        ? cur.filter((x) => x !== idx)
        : [...cur, idx];
      return next.length >= 1 ? { ...p, activeFeatures: next } : p;
    });

  // Quick: activate only top-N most important features
  const useTopN = (n) => {
    if (!result) return;
    const sorted = result.fi
      .map((imp, i) => ({ imp, i }))
      .sort((a, b) => b.imp - a.imp)
      .slice(0, n)
      .map((x) => x.i);
    setParams((p) => ({ ...p, activeFeatures: sorted }));
  };

  // -- Sub-components --
  const Slider = ({ label, helpText, min, max, step = 1, value, onChange, color = 'var(--c0)', unit = '' }) => (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
        <span style={{ fontSize: 10, fontWeight: 600, color: 'var(--text2)' }}>{label}</span>
        <span className="mono" style={{ fontSize: 11, fontWeight: 700, color }}>{value}{unit}</span>
      </div>
      {helpText && (
        <div style={{ fontSize: 8, color: 'var(--muted)', marginBottom: 5, lineHeight: 1.5 }}>{helpText}</div>
      )}
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(+e.target.value)}
        style={{ width: '100%', accentColor: color }}/>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 7, color: 'var(--muted)', marginTop: 1 }}>
        <span>{min}{unit}</span><span>{max}{unit}</span>
      </div>
    </div>
  );

  const Section = ({ title, hint, children }) => (
    <div style={{ marginBottom: 6 }}>
      <div style={{ fontSize: 8, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '.12em',
        color: 'var(--muted)', borderBottom: '1px solid var(--border)', paddingBottom: 5, marginBottom: 8, marginTop: 14 }}>
        {title}
      </div>
      {hint && (
        <div style={{ fontSize: 8, color: 'var(--muted)', marginBottom: 9, lineHeight: 1.5,
          padding: '5px 7px', background: 'var(--bg)', borderRadius: 5, borderLeft: '2px solid var(--border2)' }}>
          {hint}
        </div>
      )}
      {children}
    </div>
  );

  return (
    <aside className="fp" style={{ width: 228 }}>
      {/* Title */}
      <div style={{ fontSize: 12, fontWeight: 800, color: 'var(--text)', marginBottom: 3 }}>
        Model Controls
      </div>
      <div style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 10, lineHeight: 1.5 }}>
        Adjust any control below to re-train the model instantly. Watch how the scatter plot and accuracy change.
      </div>

      {/* Live metrics */}
      {result && (
        <div style={{ background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: 8,
          padding: '10px 11px', marginBottom: 4 }}>
          <div style={{ fontSize: 8, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase',
            letterSpacing: '.1em', marginBottom: 8 }}>
            Current Model Performance
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5, marginBottom: 8 }}>
            {[
              ['Training Score', result.trainAcc + '%', '#38bdf8',
               'How well it learned from 2019-2020 data'],
              ['Test Score',     result.testAcc + '%',  '#34d399',
               'How well it predicts 2021-2025 data'],
              ['Decision Points', result.nNodes,        'var(--text2)',
               'Total decision branches in the tree'],
              ['Final Answers',   result.nLeaves,       'var(--text2)',
               'Number of outcome leaf nodes'],
            ].map(([lbl, val, col, tip]) => (
              <div key={lbl} title={tip} style={{ background: 'var(--surface)', borderRadius: 6,
                padding: '6px 8px', cursor: 'help' }}>
                <div style={{ fontSize: 8, color: 'var(--muted)', lineHeight: 1.3 }}>{lbl}</div>
                <div className="mono" style={{ fontSize: 14, fontWeight: 700, color: col, marginTop: 2 }}>
                  {val}
                </div>
              </div>
            ))}
          </div>
          {/* Per-class accuracy */}
          <div style={{ fontSize: 8, color: 'var(--muted)', marginBottom: 5, fontWeight: 600 }}>
            Accuracy per sales category:
          </div>
          {CLASS_NAMES.map((n, i) => (
            <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
              <div style={{ width: 7, height: 7, borderRadius: '50%', background: CLASS_COLORS[i], flexShrink: 0 }}/>
              <span style={{ fontSize: 9, color: 'var(--muted)', flex: 1 }}>
                {n} sales
              </span>
              <span className="mono" style={{ fontSize: 9, color: CLASS_COLORS[i], width: 32, textAlign: 'right' }}>
                {result.perClassAcc[i]}%
              </span>
              <div style={{ width: 52, height: 4, background: 'var(--border)', borderRadius: 2 }}>
                <div style={{ height: '100%', width: result.perClassAcc[i] + '%',
                  background: CLASS_COLORS[i], borderRadius: 2, transition: 'width .4s' }}/>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* -- 1. TREE COMPLEXITY -- */}
      <Section
        title="Tree Complexity"
        hint="These two controls determine how deep and detailed the model's decision process gets.">
        <Slider
          label="How many decisions deep"
          helpText="Each level is one question the model asks (e.g. 'Is unit price over $55?'). More levels = smarter but risks memorising the data."
          min={1} max={8} value={params.maxDepth}
          onChange={(v) => upd('maxDepth', v)} color="var(--c0)"/>
        <Slider
          label="Minimum transactions per branch"
          helpText="A group must have at least this many transactions before the model splits it further. Higher = simpler, more general model."
          min={2} max={60} value={params.minSamplesSplit}
          onChange={(v) => upd('minSamplesSplit', v)} color="var(--c0)"/>
        <Slider
          label="Attributes checked per decision"
          helpText="At each decision point, how many transaction attributes can the model choose from. Lower = more random, helps prevent over-relying on one strong attribute. 'All' means use all active attributes."
          min={1} max={params.activeFeatures.length || 10}
          value={params.maxFeaturesPerSplit === null ? (params.activeFeatures.length || 10) : params.maxFeaturesPerSplit}
          onChange={(v) => upd('maxFeaturesPerSplit', v >= (params.activeFeatures.length || 10) ? null : v)}
          color="var(--c0)" unit=""/>
        {params.maxFeaturesPerSplit !== null && (
          <div style={{ fontSize: 8, color: '#fbbf24', marginTop: -8, marginBottom: 8 }}>
            Using {params.maxFeaturesPerSplit} of {params.activeFeatures.length} active attributes per split
          </div>
        )}
      </Section>

      {/* -- 2. SALES CATEGORY BOUNDARIES -- */}
      <Section
        title="Sales Category Boundaries"
        hint="Define what counts as a 'Low', 'Medium', or 'High' value sale. Moving these boundaries changes what the model learns to predict.">
        <Slider
          label={'Low / Medium cutoff (' + params.lowBoundaryPct + 'th percentile)'}
          helpText={'Sales below this amount are labelled LOW.' + (result ? ' Currently: $'+result.q1.toFixed(0) : '')}
          min={10} max={45} value={params.lowBoundaryPct}
          onChange={(v) => upd('lowBoundaryPct', Math.min(v, params.highBoundaryPct - 5))}
          color={CLASS_COLORS[0]}/>
        <Slider
          label={'Medium / High cutoff (' + params.highBoundaryPct + 'th percentile)'}
          helpText={'Sales above this amount are labelled HIGH.' + (result ? ' Currently: $'+result.q2.toFixed(0) : '')}
          min={55} max={90} value={params.highBoundaryPct}
          onChange={(v) => upd('highBoundaryPct', Math.max(v, params.lowBoundaryPct + 5))}
          color={CLASS_COLORS[2]}/>
        {result && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 4, marginBottom: 8 }}>
            {CLASS_NAMES.map((n, i) => {
              const count = [result.trainY, result.testY].flat().filter(y => y === i).length;
              return (
                <div key={n} style={{ background: CLASS_COLORS[i]+'14', border: '1px solid '+CLASS_COLORS[i]+'33',
                  borderRadius: 6, padding: '5px 6px', textAlign: 'center' }}>
                  <div style={{ fontSize: 9, fontWeight: 700, color: CLASS_COLORS[i] }}>{n}</div>
                  <div className="mono" style={{ fontSize: 8, color: 'var(--muted)', marginTop: 1 }}>
                    {count} rows
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Section>

      {/* -- 3. BIAS REDUCTION -- */}
      <Section
        title="Bias Reduction (Class Weights)"
        hint="If the model ignores a sales category (low accuracy for Low or High), increase its weight. This forces the model to try harder on that category.">
        {CLASS_NAMES.map((n, i) => (
          <Slider key={n}
            label={n + ' sales sensitivity'}
            helpText={i === 0
              ? 'Increase if the model keeps under-predicting low-value transactions.'
              : i === 1
              ? 'Increase if medium-value predictions are often wrong.'
              : 'Increase if the model misses high-value transactions (most costly errors).'}
            min={0.5} max={4} step={0.1}
            value={params.classWeights[i]}
            onChange={(v) => updWeight(i, v)}
            color={CLASS_COLORS[i]}/>
        ))}
      </Section>

      {/* -- 4. FEATURE SELECTION -- */}
      <Section
        title="Transaction Attributes to Use"
        hint="Choose which transaction details the model is allowed to consider when making decisions.">
        {/* Quick-select top N */}
        <div style={{ marginBottom: 8 }}>
          <div style={{ fontSize: 8, color: 'var(--muted)', marginBottom: 4 }}>
            Quick-select top attributes by importance:
          </div>
          <div style={{ display: 'flex', gap: 4 }}>
            {[3, 5, 7, 10].map((n) => (
              <button key={n} onClick={() => useTopN(n)} style={{
                flex: 1, padding: '3px 0', borderRadius: 4, fontSize: 9, fontWeight: 700,
                border: '1px solid var(--border)', background: 'var(--bg)',
                color: 'var(--muted)', cursor: 'pointer',
              }}>
                Top {n}
              </button>
            ))}
          </div>
        </div>

        {FEATURE_META.map((fm, idx) => {
          const active = params.activeFeatures.includes(idx);
          const fi = result ? result.fi[idx] : 0;
          const isTop = result && fi >= (result.fi.slice().sort((a,b)=>b-a)[2] || 0);
          return (
            <div key={idx} onClick={() => togFeat(idx)} style={{
              display: 'flex', alignItems: 'center', gap: 7, marginBottom: 5,
              cursor: 'pointer', padding: '5px 7px', borderRadius: 6,
              background: active ? (isTop ? CLASS_COLORS[2]+'08' : 'var(--bg)') : 'transparent',
              border: '1px solid ' + (active ? (isTop ? CLASS_COLORS[2]+'44' : 'var(--border2)') : 'var(--border)'),
              opacity: active ? 1 : 0.5,
              transition: 'all .15s',
            }}>
              <div style={{ width: 10, height: 10, borderRadius: 3, flexShrink: 0,
                background: active ? 'var(--green)' : 'var(--muted)',
                border: '1px solid ' + (active ? 'var(--green)' : 'var(--border)') }}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 9, color: active ? 'var(--text2)' : 'var(--muted)',
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {fm.name}
                </div>
                {result && (
                  <div style={{ height: 2, background: 'var(--border)', borderRadius: 1, marginTop: 2 }}>
                    <div style={{ height: '100%', width: fi + '%', background: 'var(--c0)',
                      borderRadius: 1, transition: 'width .4s' }}/>
                  </div>
                )}
              </div>
              {result && (
                <span className="mono" style={{ fontSize: 8, color: fi > 5 ? 'var(--c0)' : 'var(--muted)',
                  width: 28, textAlign: 'right', flexShrink: 0 }}>
                  {fi.toFixed(1)}%
                </span>
              )}
            </div>
          );
        })}
      </Section>

      <div style={{ marginTop: 8, padding: '7px 9px', background: 'var(--bg)', borderRadius: 6,
        border: '1px solid var(--border)', fontSize: 8, color: 'var(--muted)', lineHeight: 1.6 }}>
        The % next to each attribute = how much it contributes to the model's decisions.
        A high % means that attribute drives most of the model's choices.
      </div>
    </aside>
  );
}
